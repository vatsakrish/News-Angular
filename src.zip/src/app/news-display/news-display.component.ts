import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-news-display',
  templateUrl: './news-display.component.html',
  styleUrls: ['./news-display.component.css']
})
export class NewsDisplayComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
