import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class ApihandlerService {

  constructor(private httpclient: HttpClient) { 

  }

  private API_KEY='d0b40bc0b87f4c82aff416c6d59ac3da';

  public getData (param){
    return this.httpclient.get('https://newsapi.org/v2/top-headlines?country=ca&apiKey='+this.API_KEY);
  }
}
