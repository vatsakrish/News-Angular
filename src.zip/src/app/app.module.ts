import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { RouterModule, Routes } from '@angular/router';
import { ReactiveFormsModule } from '@angular/forms';

import { AppComponent } from './app.component';
import { TopBarComponent } from './top-bar/top-bar.component';
import { NewsContentComponent } from './news-content/news-content.component';
import { HttpClientModule } from '@angular/common/http';
import { NewsDisplayComponent } from './news-display/news-display.component'

const routes: Routes = [
  { path: '', component: NewsDisplayComponent },
  { path: 'news', component: NewsContentComponent }
];

@NgModule({
  imports: [
    BrowserModule,
    ReactiveFormsModule,
    HttpClientModule,
    RouterModule.forRoot(routes)
  ],
  exports: [RouterModule],
  declarations: [
    AppComponent,
    TopBarComponent,
    NewsContentComponent,
    NewsDisplayComponent,
  ],
  bootstrap: [ AppComponent ]
})
export class AppModule { }


/*
Copyright Google LLC. All Rights Reserved.
Use of this source code is governed by an MIT-style license that
can be found in the LICENSE file at http://angular.io/license
*/