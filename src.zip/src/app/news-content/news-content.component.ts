import { Component, OnInit } from '@angular/core';
import { ApihandlerService } from '../service/apihandler.service';

@Component({
  selector: 'app-news-content',
  templateUrl: './news-content.component.html',
  styleUrls: ['./news-content.component.css']
})
export class NewsContentComponent implements OnInit {

  constructor(private var_apiHandler: ApihandlerService) { }
  
  dataSet: any;

  ngOnInit() {
    this.sortNewsData();
  }

  private sortNewsData(){

    this.var_apiHandler.getData('').subscribe((data)=>{
      var status = data['status'];
      if(status === 'ok'){
        this.dataSet = data['articles']
      }

    });

  }
}
